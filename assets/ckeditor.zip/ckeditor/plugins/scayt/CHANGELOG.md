SCAYT plugin for CKEditor 4 Changelog
====================

The full changelog of the SCAYT plugin for CKEditor 4 can be found on our website under the [release notes](https://webspellchecker.com/release-notes/) section.
